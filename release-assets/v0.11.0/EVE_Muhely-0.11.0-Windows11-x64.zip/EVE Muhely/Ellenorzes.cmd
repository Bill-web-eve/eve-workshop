@echo off
"%~dp0runtime\python.exe" -I -X utf8 "%~dp0app\windows_smoke_test.py" --online
echo.
pause
