@echo off
start "" "%~dp0runtime\pythonw.exe" -I -X utf8 "%~dp0app\windows_desktop.py"
