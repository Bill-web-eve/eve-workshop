"""Local EVE chat-log intel. Chat contents never leave this computer."""
from __future__ import annotations
from datetime import datetime,timezone
from pathlib import Path
from collections import defaultdict
from functools import lru_cache
from urllib.parse import urlsplit,urlunsplit
import hashlib,html,json,os,re,stat,threading,time
from .planner import PlanningError
from .esi import ESI,EsiError,AuthenticationError,INTEL_SCOPES
from . import intel_universe

DEFAULTS={'enabled':False,'killfeed_enabled':True,'kill_region_ids':[],'folder':'','channels':[],'character_ids':None,'manual_locations':{},'jumps':5,'ttl_minutes':20,'cooldown_seconds':20,'region_ids':[],'allow_local_alerts':False,'sound':False,'overlay_enabled':True,'overlay_seconds':60}
FILE=re.compile(r'^(?P<channel>.+)_(?P<date>\d{8})_(?P<time>\d{6})_(?P<character>\d+)\.txt$',re.I)
LINE=re.compile(r'^\ufeff*\[\s*(\d{4}\.\d\d\.\d\d \d\d:\d\d:\d\d)\s*\]\s*([^>]{1,100})>\s*(.*)$')
LINK=re.compile(r'<url=["\']?showinfo:(137[3-9]|138[0-6])//(\d+)["\']?>(.*?)</url>',re.I)
WEB_URL=re.compile(r"(?<![\w@])(?:https?://|www\.)[^\s<>\"']+|(?<![\w@])(?:[a-z0-9-]+\.)+[a-z]{2,}/[^\s<>\"']*",re.I)
MARKUP_LINK=re.compile(r'<(url|a)\b[^>]*>.*?</\1\s*>',re.I|re.S)
PARSER_VERSION=5
NAME_LOOKUP_DELAY=2
COUNTED_GROUP=re.compile(r'(?<![\w-])([1-9]\d{0,4})\s*(?:x\s*)?(?:frat(?:ernity)?|goons?|horde|pandemic horde|init(?:iative)?|neuts?|hostiles?|reds?|pilots?|people|ships?|interceptors?|ceptors?|frigates?|frigs?|destroyers?|cruisers?|battlecruisers?|battleships?|caps(?:itals)?|bombers?)(?![\w-])',re.I)
CHUNK_SEPARATOR=re.compile(r'[|,;:()\[\]<>/]|\s{2,}|(?:\s+[+\-]\s*)|(?:->|→|=>)')
STOP=re.compile(r'\b(?:on|at|in|to|from|towards|gate|gates|out|of|with|and|or|his alts|her alts|their alts|but have|plus|jumped|jumping|jump|left|leaving|reported|seen|was|is|are|no|visual|nv|ni|onlined|docked|undocked|likely|maybe|possibly|spike|spiked|spiking|clear|clr|cleared|loc|pls|please|status|check|checkin|check-in|help|scan|scanned|reported|still|just|now|local|heading|destination|need|needle|red|reds|new|ago|minutes?|minute|min|camp|camping|for|the|a|an|cloaked|cloak|suspect|scout|unknown|neut|neuts|neutral|hostile|hostiles|fleets?|tackled)\b',re.I)


def schema(store):
    with store.db() as db:db.executescript('''
        CREATE TABLE IF NOT EXISTS intel_config(id INTEGER PRIMARY KEY,data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS intel_files(id TEXT PRIMARY KEY,device INTEGER,inode INTEGER,offset INTEGER,encoding TEXT,channel TEXT,seen REAL);
        CREATE TABLE IF NOT EXISTS intel_reports(id TEXT PRIMARY KEY,ts REAL,channel TEXT,reporter TEXT,body TEXT,data TEXT,received REAL);
        CREATE INDEX IF NOT EXISTS intel_report_time ON intel_reports(ts);
        CREATE TABLE IF NOT EXISTS intel_local_positions(character_id INTEGER PRIMARY KEY,data TEXT);
        CREATE TABLE IF NOT EXISTS intel_status(id INTEGER PRIMARY KEY,data TEXT);
        CREATE TABLE IF NOT EXISTS intel_characters(name TEXT PRIMARY KEY,id INTEGER,canonical TEXT,checked REAL,retry_at REAL);
    ''')
    from . import intel_kills
    intel_kills.schema(store)


def preferences(store):
    schema(store)
    with store.db() as db:row=db.execute('SELECT data FROM intel_config WHERE id=1').fetchone()
    return {**DEFAULTS,**(json.loads(row['data']) if row else {})}


def save_preferences(store,data,universe):
    if not isinstance(data,dict) or set(data)-set(DEFAULTS):raise PlanningError('Hibás intelbeállítás.')
    p=preferences(store);known={c['id'] for c in store.characters()}
    for key,value in data.items():
        if key in ['enabled','killfeed_enabled','allow_local_alerts','sound','overlay_enabled']:
            if type(value) is not bool:raise PlanningError('Hibás intelkapcsoló.')
        elif key=='folder':
            if not isinstance(value,str) or len(value)>2000:raise PlanningError('Hibás chatlogmappa.')
            value=str(Path(value).expanduser().resolve()) if value.strip() else ''
            if value and not Path(value).is_dir():raise PlanningError('A chatlogmappa nem érhető el. Válassz létező mappát.')
        elif key=='channels':
            if not isinstance(value,list) or len(value)>100 or any(not isinstance(c,str) or not c.strip() or len(c)>160 for c in value):raise PlanningError('Hibás intelcsatorna-lista.')
            value=list(dict.fromkeys(c.strip() for c in value))
        elif key=='character_ids':
            if value is not None and (not isinstance(value,list) or any(type(v) is not int or v not in known for v in value)):raise PlanningError('Ismeretlen intelkarakter.')
            if value is not None:value=list(dict.fromkeys(value))
        elif key=='manual_locations':
            if not isinstance(value,dict) or any(not isinstance(k,str) or not k.isdigit() or int(k) not in known or type(v) is not int or v not in universe.systems for k,v in value.items()):raise PlanningError('Hibás kézi intelhelyszín.')
        elif key in ['region_ids','kill_region_ids']:
            valid={r['region_id'] for r in universe.systems.values()}
            if not isinstance(value,list) or any(type(v) is not int or v not in valid for v in value):raise PlanningError('Ismeretlen intelrégió.')
        else:
            low,high={'jumps':(0,30),'ttl_minutes':(1,120),'cooldown_seconds':(0,600),'overlay_seconds':(1,3600)}[key]
            if type(value) is not int or not low<=value<=high:raise PlanningError('Az intelérték kívül esik a megengedett tartományon.')
        p[key]=value
    if p['enabled'] and (not p['folder'] or not p['channels']):raise PlanningError('A figyeléshez válassz chatlogmappát és legalább egy csatornát.')
    with store.db() as db:db.execute('INSERT OR REPLACE INTO intel_config VALUES(1,?)',(json.dumps(p),))
    return p


def without_web_links(body):
    """Keep original chat separately; external URLs and their captions are not intel."""
    text=html.unescape(body)
    text=MARKUP_LINK.sub(lambda m:' ' if WEB_URL.search(m.group().split('>',1)[0]) else m.group(),text)
    text=WEB_URL.sub(' ',text)
    return text,text!=html.unescape(body)


def scan_links(body):
    links=[]
    for match in WEB_URL.finditer(html.unescape(body)):
        raw=match.group().rstrip('.,;:!?)]}')
        try:
            url=urlsplit(raw if '://' in raw else 'https://'+raw)
            if url.scheme.casefold() not in ['http','https'] or url.username or url.password or url.port not in [None,443]:continue
            if url.hostname not in ['dscan.info','www.dscan.info','adashboard.info','www.adashboard.info']:continue
            if not url.path.strip('/'):continue
            value=urlunsplit(('https',url.hostname,url.path,url.query,url.fragment))
        except ValueError:continue
        if value not in links:links.append(value)
        if len(links)==5:break
    return links


def name_chunks(text,universe):
    start=0;result=[]
    def add(first,last):
        name=re.sub(r'\s+',' ',text[first:last]).strip(' .!*+"\t-')
        if 3<=len(name)<=64 and len(name.split())<=8 and re.search('[A-Za-zÀ-ž]',name) and re.fullmatch(r"[\w .’'\-]+",name) and not re.match(r'^\d+(?:\s|$)',name) and not STOP.fullmatch(name) and not universe.ship_pattern.fullmatch(name):result.append((first,last,name))
    for end,following in [(m.start(),m.end()) for m in CHUNK_SEPARATOR.finditer(text)]+[(len(text),len(text))]:
        add(start,end)
        for ship in universe.ship_pattern.finditer(text[start:end]):
            tail=STOP.sub(' ',universe.ship_pattern.sub(' ',text[start+ship.start():end]))
            if not re.search('[A-Za-zÀ-ž]',tail):add(start,start+ship.start())
        start=following
    return list(dict.fromkeys(result))[:24]


def parse_message(line,universe,channel,channel_id,now=None,regions=(),known_names=()):
    match=LINE.match(line.strip());now=time.time() if now is None else now
    if not match:return None
    date,reporter,body=match.groups();reporter=reporter.strip();body=body[:4000]
    if reporter.casefold() in ['eve system','eve-system']:return None
    try:at=datetime.strptime(date,'%Y.%m.%d %H:%M:%S').replace(tzinfo=timezone.utc).timestamp()
    except ValueError:return None
    if at>now+60:return None
    cleaned,had_web_links=without_web_links(body);scans=scan_links(body)
    linked=[{'name':re.sub('<[^>]+>','',m[3]).strip(),'id':int(m[2]),'verified':True} for m in LINK.finditer(cleaned)]
    plain=re.sub('<[^>]+>','',LINK.sub(' ',cleaned))
    # A linked character can be named after a system. Do not parse their name as a location.
    searching=COUNTED_GROUP.sub(lambda m:' '*len(m.group()),plain)
    # Racial ship names such as Amarr Shuttle also contain real system names.
    searching=universe.ship_pattern.sub(lambda m:' '*len(m.group()),searching)
    mentions=universe.mentions(searching,regions)
    ids=list(dict.fromkeys(sid for sid,_,_ in mentions))
    arrow=bool(re.search(r'(?:->|→|=>)',plain))
    if arrow and len(ids)>1:ids=ids[-1:]
    question='?' in plain
    is_clear=bool(re.search(r'(?<!\w)(?:clr|clear|cleared|tiszta)(?!\w)',plain,re.I)) and not re.search(r'\b(?:not|no|nem)\s+(?:clr|clear|cleared|tiszta)\b',plain,re.I)
    state='query' if question else 'clear' if is_clear else 'contact' if ids else 'unparsed'
    text=searching;remaining=plain
    for _,(start,end),_ in reversed(mentions):
        text=text[:start]+' '*max(1,end-start)+text[end:]
        remaining=remaining[:start]+' '*max(1,end-start)+remaining[end:]
    chunks=name_chunks(remaining,universe);known={name.casefold() for name in known_names};trusted=[];ship_text=plain
    occupied=[]
    for start,end,name in sorted(chunks,key=lambda c:-len(c[2])):
        if name.casefold() in known and not any(start<b and end>a for a,b in occupied):
            occupied.append((start,end))
            trusted.append({'name':name,'id':None,'verified':False})
            text=text[:start]+' '*(end-start)+text[end:]
            ship_text=ship_text[:start]+' '*(end-start)+ship_text[end:]
    text=universe.pattern.sub(' ',text);text=universe.ship_pattern.sub(' ',text)
    ships=universe.reported_ships(ship_text)
    # Ordinary links are informational; recognized scans have their own visible reference.
    if state=='contact' and had_web_links and not scans and not linked and not ships and not re.search(r'\w',remaining):state='unparsed'
    text=re.sub(r'(?:\+\s*\d+|\b(?:\d+\s*x|x\s*\d+)\b)',' ',text,flags=re.I)
    candidates=[]
    for chunk in CHUNK_SEPARATOR.split(text):
        parts=STOP.split(chunk)
        for part in parts:
            name=re.sub(r'\s+',' ',part).strip(' .!*+"\t-')
            if 2<=len(name)<=64 and len(name.split())<=4 and re.search('[A-Za-zÀ-ž]',name) and re.fullmatch(r"[\w .’'\-]+",name) and not name.isdigit():
                if name.casefold() not in {p['name'].casefold() for p in linked+trusted}:candidates.append({'name':name,'id':None,'verified':False})
    pilots=list({p['name'].casefold():p for p in linked+trusted+candidates}.values())[:12] if state=='contact' else []
    count=re.search(r'(?:\+|\bspike\s+)(\d{1,5})\b',plain,re.I) or COUNTED_GROUP.search(plain)
    key='\0'.join([channel_id or channel.casefold(),date,reporter,body]);identity=hashlib.sha256(key.encode()).hexdigest()
    return {'id':identity,'timestamp':at,'channel':channel,'reporter':reporter,'message':body,'systems':ids,'pilots':pilots,'ships':ships,'scan_links':scans,'name_chunks':[name for _,_,name in chunks],'state':state,'count':min(10000,int(count[1])) if count else len(pilots) or None,'ambiguous':len(ids)>1,'abbreviated':any(short for _,_,short in mentions),'parser_version':PARSER_VERSION}


def enrich_reports(store,universe,reports):
    """Resolve exact names locally from the cache; never wait for network in a map request."""
    with store.db() as db:known={r['name']:dict(r) for r in db.execute('SELECT * FROM intel_characters WHERE id IS NOT NULL')}
    own={c['name'].casefold():c for c in store.characters()}
    for row in reports:
        row['ships']=row.get('ships',universe.reported_ships(html.unescape(re.sub('<[^>]+>','',LINK.sub(' ',row['message'])))))
        for ship in row['ships']:
            if ship.get('type_id') is None:ship['type_id']=universe.ship_types.get(ship['name'].casefold())
        for pilot in row['pilots']:
            entry=known.get(pilot['name'].casefold());char=own.get(pilot['name'].casefold())
            if not pilot.get('id') and (entry or char):pilot['id']=entry['id'] if entry else char['id'];pilot['identified']=True
            pilot['zkill_url']=f"https://zkillboard.com/character/{pilot['id']}/" if type(pilot.get('id')) is int and pilot['id']>0 else None
    return reports


def preload_character_cache(store,reports=(),now=None):
    """Reuse character identities already downloaded elsewhere, without network requests."""
    now=time.time() if now is None else now;entries={}
    with store.db() as db:
        if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='fleet_sources'").fetchone():
            row=db.execute("SELECT data,checked FROM fleet_sources WHERE key='battle-names'").fetchone()
            if row:
                try:values=json.loads(row['data'])
                except (ValueError,TypeError):values={}
                for ident,value in (values.items() if isinstance(values,dict) else []):
                    if isinstance(value,dict) and value.get('category')=='character' and str(ident).isdigit() and int(ident)>0 and isinstance(value.get('name'),str) and 3<=len(value['name'])<=64:
                        entries[value['name'].casefold()]=(int(ident),value['name'],min(now,row['checked'] or 0))
        for report in reports:
            for pilot in report['pilots']:
                if pilot.get('verified') and type(pilot.get('id')) is int and pilot['id']>0 and 3<=len(pilot['name'])<=64:
                    entries[pilot['name'].casefold()]=(pilot['id'],pilot['name'],report['timestamp'])
        db.executemany('''INSERT INTO intel_characters(name,id,canonical,checked,retry_at) VALUES(?,?,?,?,?)
            ON CONFLICT(name) DO UPDATE SET id=excluded.id,canonical=excluded.canonical,checked=excluded.checked,retry_at=excluded.retry_at
            WHERE intel_characters.id IS NULL OR (intel_characters.id=excluded.id AND intel_characters.checked<excluded.checked)''',
            [(name,ident,canonical,checked,checked+30*86400) for name,(ident,canonical,checked) in entries.items()])
        return db.execute('SELECT count(*) FROM intel_characters WHERE id IS NOT NULL').fetchone()[0]


def selected_characters(store,p):return [c for c in store.characters() if p['character_ids'] is None or c['id'] in p['character_ids']]


def positions(store,universe,p,now):
    result=[]
    with store.db() as db:locals={r['character_id']:json.loads(r['data']) for r in db.execute('SELECT * FROM intel_local_positions')}
    for char in selected_characters(store,p):
        cid=char['id'];manual=p['manual_locations'].get(str(cid));snap=store.snapshot(cid,'intel_position');status=store.resource_status(cid,'intel_location') or {}
        row={'id':cid,'name':char['name'],'system_id':None,'source':'unknown','as_of':None,'alertable':False,'needs_auth':bool(status.get('needs_auth',True)),'error':status.get('error'),'online':None}
        if manual in universe.systems:row.update(system_id=manual,source='manual',alertable=True)
        elif snap and snap['expires']>now and not status.get('error'):
            data=snap['data'];fresh=snap['expires']>now and not status.get('error')
            row.update(system_id=data.get('solar_system_id'),source='esi',as_of=snap['fetched'],online=data.get('online'),alertable=fresh and data.get('online') is True,needs_auth=bool(status.get('needs_auth')))
        elif cid in locals and (not snap or locals[cid]['checked']>=snap['fetched']):
            data=locals[cid];row.update(system_id=data['system_id'],source='local',as_of=data['checked'],alertable=p['allow_local_alerts'] and 0<=now-data['checked']<=300)
        elif snap:
            data=snap['data'];row.update(system_id=data.get('solar_system_id'),source='esi',as_of=snap['fetched'],online=data.get('online'))
        row['system_name']=universe.systems.get(row['system_id'],{}).get('name');result.append(row)
    return result


@lru_cache(maxsize=4096)
def reparse_report(message,timestamp,reporter,channel,universe,regions,known_names=()):
    date=datetime.fromtimestamp(timestamp,timezone.utc).strftime('%Y.%m.%d %H:%M:%S')
    parsed=parse_message(f'[ {date} ] {reporter} > {message}',universe,channel,'',timestamp,regions,known_names)
    return json.dumps(parsed) if parsed else None


def read_reports(store,p,now,universe=None):
    channels={s.casefold() for s in p['channels']}
    with store.db() as db:
        rows=db.execute('SELECT data FROM intel_reports WHERE ts>=? AND ts<=? ORDER BY ts DESC LIMIT 3000',(now-86400,now+60)).fetchall()
        known={r[0] for r in db.execute('SELECT name FROM intel_characters WHERE id IS NOT NULL')}
    reports=[]
    for raw in rows:
        row=json.loads(raw['data'])
        if row['channel'].casefold() not in channels:continue
        # Reinterpret old reports once per parser version; never delete history or change IDs.
        if row.get('parser_version',0)<PARSER_VERSION:
            universe=universe or intel_universe.load(store)
            parsed=reparse_report(row['message'],row['timestamp'],row['reporter'],row['channel'],universe,tuple(p['region_ids']))
            if parsed:row={**row,**json.loads(parsed),'id':row['id']}
        trusted=tuple(name for name in row.get('name_chunks',[]) if name.casefold() in known)
        if trusted:
            universe=universe or intel_universe.load(store)
            parsed=reparse_report(row['message'],row['timestamp'],row['reporter'],row['channel'],universe,tuple(p['region_ids']),trusted)
            if parsed:row={**row,**json.loads(parsed),'id':row['id']}
        reports.append(row)
    return reports


def active_state(reports,now,ttl,owned=()):
    ordered=sorted(reports,key=lambda r:(r['timestamp'],r['state']=='clear',r['id']))
    cleared={};latest_pilot={};active=[]
    for row in ordered:
        if row['timestamp']>now:continue
        if row['state']=='clear':
            for sid in row['systems']:cleared[sid]=row['timestamp']
        elif row['state']=='contact' and not row['ambiguous']:
            for pilot in row['pilots']:latest_pilot[pilot['name'].casefold()]=row['id']
    for row in ordered:
        if row['state']!='contact' or not 0<=now-row['timestamp']<=ttl:continue
        remaining=[p for p in row['pilots'] if p['name'].casefold() not in owned and (row['ambiguous'] or latest_pilot.get(p['name'].casefold())==row['id'])]
        if row['pilots'] and not remaining:continue
        for sid in row['systems']:
            if row['timestamp']>cleared.get(sid,0):active.append({**row,'system_id':sid,'pilots':remaining})
    return active,cleared


def collect_alerts(store,universe=None,now=None):
    from .notifications import preferences as notification_preferences
    now=time.time() if now is None else now;p=preferences(store);universe=universe or intel_universe.load(store)
    notifications_enabled=notification_preferences(store)['categories']['intel']
    with store.db() as db:row=db.execute('SELECT data FROM intel_status WHERE id=1').fetchone()
    status=json.loads(row['data']) if row else {}
    from . import intel_kills
    chat_ready=p['enabled'] and not status.get('error') and now-(status.get('checked') or 0)<=10
    pos=positions(store,universe,p,now);reports=read_reports(store,p,now,universe);owned={c['name'].casefold() for c in store.characters()}
    active,cleared=active_state(reports,now,p['ttl_minutes']*60,owned);items=[];domains=[]
    by_system=defaultdict(list)
    for r in active:
        if chat_ready and not r.get('historical') and not r['ambiguous']:by_system[r['system_id']].append(r)
    for char in pos:
        if not chat_ready or not char['alertable']:continue
        domain='intel:'+str(char['id']);domains.append(domain);distances=universe.distances(char['system_id'])
        for sid,rows in by_system.items():
            distance=distances.get(sid)
            if distance is None or distance>p['jumps']:continue
            pilots=sorted({p['name'] for r in rows for p in r['pilots']});scans=list(dict.fromkeys(url for r in rows for url in r.get('scan_links',[])))[:5];identity=hashlib.sha256('\0'.join(pilots or scans or ['unnamed']).encode()).hexdigest()[:20]
            key=f"intel:{char['id']}:{sid}:{identity}";newest=max(rows,key=lambda r:r['timestamp']);name=universe.systems[sid]['name']
            items.append({'id':key,'domain':domain,'category':'intel','kind':'intel_near','subject':name+(' · '+', '.join(pilots[:6]) if pilots else ''),'corporation_id':None,'scope_name':'Személyes','when':newest['timestamp'],'checked_at':status['checked'],'reliable':True,'character_id':char['id'],'character_name':char['name'],'system_id':sid,'jumps':distance,'pilots':pilots,'report_id':newest['id'],'sound':p['sound'],'cooldown':p['cooldown_seconds']})
            items[-1]['episode_key']=str(int(cleared.get(sid,0)))
            items[-1]['system_name']=name
            items[-1]['scan_links']=scans
            items[-1]['overlay_reports']=[{'id':r['id'],'when':r['timestamp'],'pilots':[pilot['name'] for pilot in r['pilots']],'ships':[ship['name'] for ship in r.get('ships',[])],'scan_links':r.get('scan_links',[])} for r in rows]
    kills,kill_domains=intel_kills.alerts(store,universe,p,pos,now);items+=kills;domains+=kill_domains
    return {'items':items,'observed_domains':domains,'enabled':p['enabled'] or p['killfeed_enabled'],'notifications_enabled':notifications_enabled,'overlay':{'enabled':p['overlay_enabled'] and notifications_enabled,'seconds':p['overlay_seconds']}}


from .refresh_policy import RefreshPolicy,AUTO_SECONDS

class IntelMonitor:
    def __init__(self,store,catalog,eve,universe=None):
        self.refresh_policy=RefreshPolicy(store)
        self.store=store;self.catalog=catalog;self.eve=eve;self.universe=universe or intel_universe.load(store)
        if catalog and isinstance(getattr(catalog,'types',None),dict):
            self.universe.ship_types.update({t['name'].casefold():t['id'] for t in catalog.types.values() if t['name'].casefold() in self.universe.ship_names})
        self.lock=threading.RLock();self.stop_event=threading.Event();self.refresh_event=threading.Event();self.thread=None;self.headers={};self.started=time.time();self.last_locations=0;self.location_thread=None;self.closed=False;self.names_thread=None;self.last_names=0;self.names_due=None;self.names_next_attempt=0
        self.status={'running':False,'scanning':False,'checked':None,'files':0,'done':0,'new_messages':0,'error':None,'file_errors':0};self.preload_pending=False
        schema(store)
        self.status['known_characters']=preload_character_cache(store)
        with store.db() as db:previous=db.execute('SELECT data FROM intel_status WHERE id=1').fetchone()
        if previous:
            retry=json.loads(previous['data']).get('names_retry_at',0)
            if isinstance(retry,(int,float)) and retry>time.time():self.status['names_retry_at']=retry;self.names_due=retry
        if preferences(store)['enabled']:self.start()
    def start(self):
        with self.lock:
            if self.thread and self.thread.is_alive():return
            self.stop_event.clear();self.started=time.time();self.preload_pending=True;self.thread=threading.Thread(target=self._work,daemon=True,name='EVE-intel');self.thread.start()
    def stop(self,permanent=True):
        if permanent:self.closed=True
        self.stop_event.set()
        if self.thread and self.thread is not threading.current_thread():self.thread.join(timeout=3)
        with self.lock:self.status['running']=False
    def configure(self,data):
        p=save_preferences(self.store,data,self.universe)
        self.started=time.time()
        if p['enabled']:self.start();self.refresh_event.set()
        else:self.stop(permanent=False)
        return p
    def request_locations(self):
        self.refresh_event.set();self._start_locations(preferences(self.store),manual=True)
    def queue_characters(self):
        with self.lock:
            if self.names_due is None:self.names_due=max(time.time(),self.names_next_attempt)
    def poll_characters(self,new_messages=False):
        now=time.time()
        if now-self.last_names>=AUTO_SECONDS or new_messages:
            self.last_names=now;self.queue_characters()
        if self.names_due is not None and now>=self.names_due:self.request_characters()
    def request_characters(self,manual=False,preload=False):
        with self.lock:
            if preload:self.preload_pending=True
            now=time.time()
            if self.names_thread and self.names_thread.is_alive() or self.closed or now<max(self.names_next_attempt,self.status.get('names_retry_at',0)):return
            if not manual and self.names_due is not None and now<self.names_due:return
            self.names_due=None
            self.status['resolving_characters']=True;self.status['names_done']=0;self.status['names_total']=0
            def work():
                try:self.resolve_characters(preload=self.preload_pending)
                finally:
                    with self.lock:self.status['resolving_characters']=False
                    self._write_status()
            self.names_thread=threading.Thread(target=work,daemon=True,name='EVE-intel-names');self.names_thread.start()
    def resolve_characters(self,now=None,preload=False):
        now=time.time() if now is None else now;p=preferences(self.store);reports=read_reports(self.store,p,now,self.universe)
        known_count=preload_character_cache(self.store,reports,now)
        own={c['name'].casefold() for c in self.store.characters()}
        names={}
        for row in reports:
            candidates=(row.get('name_chunks',[]) if preload and row['state']=='contact' else [])+[pilot['name'] for pilot in row['pilots'] if not pilot.get('id')]
            for name in candidates:
                if 3<=len(name)<=64 and name.casefold() not in own:names.setdefault(name.casefold(),name)
        if preload:
            for row in reports:
                name=row['reporter']
                if 3<=len(name)<=64 and name.casefold() not in own:names.setdefault(name.casefold(),name)
        with self.store.db() as db:cache={r['name']:dict(r) for r in db.execute('SELECT * FROM intel_characters')}
        names=[name for key,name in names.items() if key not in cache or cache[key]['retry_at']<=now]
        with self.lock:self.status.update(names_total=len(names),names_done=0,names_error=None,names_retry_at=0,known_characters=known_count)
        for start in range(0,len(names),100):
            if self.closed:return
            if start and self.stop_event.wait(NAME_LOOKUP_DELAY):return
            batch=names[start:start+100]
            try:
                with self.lock:self.names_next_attempt=time.time()+NAME_LOOKUP_DELAY
                result,_=self.eve.http.request(ESI+'/universe/ids/',json_body=batch)
                if not isinstance(result,dict) or not isinstance(result.get('characters',[]),list):raise EsiError('A pilótaazonosítók most nem ellenőrizhetők.')
                requested={name.casefold() for name in batch};found={}
                for char in result.get('characters',[]):
                    if isinstance(char,dict) and isinstance(char.get('name'),str) and char['name'].casefold() in requested and type(char.get('id')) is int and char['id']>0:found[char['name'].casefold()]=char
                if self.closed:return
                with self.store.db() as db:
                    for name in batch:
                        entry=found.get(name.casefold());previous=cache.get(name.casefold())
                        if not entry and previous and previous['id']:
                            # An empty response does not invalidate an already identified pilot.
                            db.execute('UPDATE intel_characters SET retry_at=? WHERE name=?',(now+3600,name.casefold()))
                        else:db.execute('INSERT OR REPLACE INTO intel_characters VALUES(?,?,?,?,?)',(name.casefold(),entry['id'] if entry else None,entry['name'] if entry else name,now,now+(30*86400 if entry else 3600)))
                with self.lock:self.status['names_done']=min(start+100,len(names))
                if preload and start+100<len(names):self.queue_characters();return
            except EsiError:
                blocked=getattr(self.eve.http,'blocked_until',0)
                retry=max(time.time()+60,blocked if isinstance(blocked,(int,float)) else 0)
                with self.lock:
                    self.status.update(names_error='A pilótaazonosítók most nem ellenőrizhetők.',names_retry_at=retry)
                    self.names_due=retry
                return
        if preload:
            with self.lock:self.preload_pending=False
        with self.store.db() as db:known_count=db.execute('SELECT count(*) FROM intel_characters WHERE id IS NOT NULL').fetchone()[0]
        with self.lock:self.status['known_characters']=known_count
    def _start_locations(self,p,manual=False):
        with self.lock:
            if self.location_thread and self.location_thread.is_alive():return
            if not self.refresh_policy.claim(['intel-locations'],manual):return
            self.status['location_refreshing']=True
        def work():
            try:self.refresh_locations(p)
            finally:
                self.refresh_policy.claim(['intel-locations'],manual=True)
                with self.lock:self.status['location_refreshing']=False;self.status['location_character']=None
        self.location_thread=threading.Thread(target=work,daemon=True,name='EVE-intel-location');self.location_thread.start()

    def _write_status(self):
        with self.lock:value=dict(self.status)
        with self.store.db() as db:db.execute('INSERT OR REPLACE INTO intel_status VALUES(1,?)',(json.dumps(value),))
    def _work(self):
        while not self.stop_event.is_set():
            try:
                p=preferences(self.store)
                if not p['enabled']:break
                self.scan(p)
                if self.status['new_messages']:self.preload_pending=True
                self.poll_characters(self.status['new_messages'])
                if time.time()-self.last_locations>=AUTO_SECONDS or self.refresh_event.is_set():
                    self.refresh_event.clear();self.last_locations=time.time();self._start_locations(p)
            except Exception as error:
                with self.lock:self.status.update(error=str(error) if isinstance(error,(PlanningError,EsiError)) else 'Az intelolvasás nem sikerült. Ellenőrizd a mappa hozzáférését.',checked=time.time(),scanning=False)
                self._write_status()
            self.stop_event.wait(1)
        with self.lock:self.status['running']=False;self.status['scanning']=False
        self._write_status()
    def channels(self,folder):
        root=Path(folder).expanduser()
        try:
            names={match['channel'] for f in root.iterdir() if f.is_file() and not f.is_symlink() and (match:=FILE.match(f.name))}
        except OSError:raise PlanningError('A chatlogmappa nem olvasható. Ellenőrizd a hozzáférési engedélyt.') from None
        return sorted(names,key=str.casefold)
    def scan(self,p=None,now=None):
        now=time.time() if now is None else now;p=p or preferences(self.store);root=Path(p['folder'])
        if not root.is_dir():raise PlanningError('A chatlogmappa nem érhető el.')
        allowed={s.casefold() for s in p['channels']};characters={c['id']:c for c in self.store.characters()}
        files=[]
        try:
            for f in root.iterdir():
                m=FILE.match(f.name)
                if m and not f.is_symlink() and f.is_file() and (m['channel'].casefold() in allowed or m['channel']=='Local' and int(m['character']) in characters):
                    if now-f.stat().st_mtime<=86400*2:files.append((f,m))
        except OSError:raise PlanningError('A chatlogmappa nem olvasható. Ellenőrizd a hozzáférési engedélyt.') from None
        files.sort(key=lambda row:row[0].stat().st_mtime,reverse=True)
        with self.lock:self.status.update(running=True,scanning=True,files=len(files),done=0,error=None,file_errors=0,new_messages=0)
        self._write_status()
        for index,(f,m) in enumerate(files):
            if self.stop_event.is_set():break
            try:count=self._file(f,m,p,characters,now)
            except (OSError,UnicodeError,ValueError):
                count=0
                with self.lock:self.status['file_errors']+=1
            with self.lock:self.status['done']=index+1;self.status['new_messages']+=count
        with self.lock:self.status.update(checked=now,scanning=False)
        self._write_status()
        with self.store.db() as db:
            db.execute('DELETE FROM intel_reports WHERE ts<?',(now-86400,));db.execute('DELETE FROM intel_files WHERE seen<?',(now-86400*30,))
    def _file(self,path,match,p,characters,now):
        flags=os.O_RDONLY|getattr(os,'O_NOFOLLOW',0);fd=os.open(path,flags)
        with os.fdopen(fd,'rb') as f:
            info=os.fstat(f.fileno())
            if not stat.S_ISREG(info.st_mode):return 0
            key=hashlib.sha256(str(path.resolve()).encode()).hexdigest()
            with self.store.db() as db:old=db.execute('SELECT * FROM intel_files WHERE id=?',(key,)).fetchone()
            offset=old['offset'] if old and old['device']==info.st_dev and old['inode']==info.st_ino and old['offset']<=info.st_size else 0
            # Do not reopen or decode the complete file on each poll.
            if old and offset==info.st_size:return 0
            header_key=(key,info.st_dev,info.st_ino)
            if old and old['offset']>info.st_size:self.headers.pop(header_key,None)
            if header_key not in self.headers:
                head=f.read(8192);encoding='utf-16-le' if head.startswith(b'\xff\xfe') else 'utf-16-be' if head.startswith(b'\xfe\xff') else 'utf-8-sig'
                text=head[:len(head)//2*2].decode(encoding,errors='replace') if encoding.startswith('utf-16') else head.decode(encoding,errors='replace')
                fields={k:v.strip() for k,v in re.findall(r'^\s*(Channel ID|Channel Name|Listener):\s*(.*?)\s*$',text,re.M)}
                if not fields.get('Channel Name') or not fields.get('Listener'):return 0
                self.headers[header_key]=(encoding,fields)
            encoding,fields=self.headers[header_key];channel=fields['Channel Name'];cid=int(match['character'])
            local=channel=='Local' and cid in characters and fields['Listener']==characters[cid]['name']
            if not local and channel.casefold() not in {c.casefold() for c in p['channels']}:return 0
            f.seek(offset);chunk=f.read(4*1024*1024);separator=b'\n\x00' if encoding=='utf-16-le' else b'\x00\n' if encoding=='utf-16-be' else b'\n'
            end=chunk.rfind(separator)
            if encoding.startswith('utf-16'):
                while end>=0 and end%2:end=chunk.rfind(separator,0,end)
            if end<0:
                if len(chunk)>=4*1024*1024:raise ValueError('Oversized log line')
                return 0
            used=end+len(separator);text=chunk[:used].decode(encoding);count=0
            with self.store.db() as db:
                for line in text.splitlines():
                    raw=LINE.match(line.strip())
                    if local:
                        if not raw:continue
                        try:at=datetime.strptime(raw[1],'%Y.%m.%d %H:%M:%S').replace(tzinfo=timezone.utc).timestamp()
                        except ValueError:continue
                        if at>now+60:continue
                        moved=re.search(r'Channel changed to Local\s*:\s*(.+)',raw[3]) if raw[2].strip()=='EVE System' else None
                        row=db.execute('SELECT data FROM intel_local_positions WHERE character_id=?',(cid,)).fetchone();position=json.loads(row['data']) if row else None
                        if moved and (sid:=self.universe.resolve(moved[1])) and (not position or at>=position['checked']):position={'system_id':sid,'changed':at,'checked':at}
                        elif position and at>=position['checked']:position['checked']=at
                        if position:db.execute('INSERT OR REPLACE INTO intel_local_positions VALUES(?,?)',(cid,json.dumps(position)))
                    else:
                        report=parse_message(line,self.universe,channel,fields.get('Channel ID',''),now,p['region_ids'])
                        if not report or report['timestamp']<now-86400:continue
                        report.update(historical=report['timestamp']<self.started-5,received=now)
                        cur=db.execute('INSERT OR IGNORE INTO intel_reports VALUES(?,?,?,?,?,?,?)',(report['id'],report['timestamp'],channel,report['reporter'],report['message'],json.dumps(report),now));count+=cur.rowcount
                db.execute('INSERT OR REPLACE INTO intel_files VALUES(?,?,?,?,?,?,?)',(key,info.st_dev,info.st_ino,offset+used,encoding,channel,now))
            return count
    def refresh_locations(self,p=None,now=None):
        p=p or preferences(self.store);now=time.time() if now is None else now
        for char in selected_characters(self.store,p):
            if self.closed:break
            if str(char['id']) in p['manual_locations']:continue
            status=self.store.resource_status(char['id'],'intel_location')
            if status and status['needs_auth']:continue
            with self.lock:self.status['location_character']=char['name']
            try:
                token=self.eve.token(char['id'],required_scopes=INTEL_SCOPES);parts={}
                for resource in ['location','online']:
                    key='intel_'+resource;old=self.store.snapshot(char['id'],key)
                    if old and old['expires']>now:parts[key]=old;continue
                    body,headers=self.eve.http.request(f"{ESI}/characters/{char['id']}/{resource}/",token=token,headers={'If-None-Match':old['etag']} if old and old.get('etag') else {})
                    h={k.lower():v for k,v in headers.items()};data=old['data'] if body is None and old else body
                    if not isinstance(data,dict) or (resource=='location' and (type(data.get('solar_system_id')) is not int or data['solar_system_id'] not in self.universe.systems)) or (resource=='online' and type(data.get('online')) is not bool):raise EsiError('Hiányos EVE-helyzetadat.')
                    max_age=re.search(r'max-age="?(\d+)',h.get('cache-control',''));ttl=max(1,int(max_age[1])-int(h.get('age','0'))) if max_age else 5
                    parts[key]={'data':data,'fetched':now,'expires':now+ttl,'etag':h.get('etag') or (old or {}).get('etag')}
                parts['intel_position']={'data':{**parts['intel_location']['data'],'online':parts['intel_online']['data']['online']},'fetched':min(r['fetched'] for r in parts.values()),'expires':min(r['expires'] for r in parts.values()),'etag':None}
                if not self.closed:self.store.save_snapshots(char['id'],parts,domain='intel_location')
            except (EsiError,ValueError) as error:self.store.resource_error(char['id'],'intel_location',str(error) if isinstance(error,EsiError) else 'Hiányos EVE-helyzetadat.',isinstance(error,AuthenticationError))
    def dashboard(self,center=None,radius=5,history=False,now=None,region=None,character_id=None):
        now=time.time() if now is None else now;p=preferences(self.store);universe=self.universe;pos=positions(self.store,universe,p,now);reports=enrich_reports(self.store,universe,read_reports(self.store,p,now,universe))
        active,cleared=active_state(reports,now,p['ttl_minutes']*60,{c['name'].casefold() for c in self.store.characters()})
        reference=next((c for c in pos if c['id']==character_id),None) or next((c for c in pos if c['alertable']),None) or next((c for c in pos if c['system_id'] in universe.systems),None) or next(iter(pos),None)
        origin=reference['system_id'] if reference else None
        if center not in universe.systems:center=origin if origin in universe.systems else next((r['systems'][0] for r in reports if r['systems']),None)
        regions={s['region_id']:s['region'] for s in universe.systems.values()}
        if region is not None and region not in regions:raise PlanningError('Ismeretlen intelrégió.')
        region=region or universe.systems.get(center,{}).get('region_id')
        distance=universe.distances(origin);ids={sid for sid,s in universe.systems.items() if s['region_id']==region};clipped=False
        from . import intel_kills
        kill_groups=intel_kills.groups(self.store,universe,p,now,{region} if region else set());kill_by_system=defaultdict(list)
        for g in kill_groups:kill_by_system[g['system_id']].append(g)
        by_sid=defaultdict(list)
        for row in active:by_sid[row['system_id']].append(row)
        last={}
        for row in reports:
            for sid in row['systems']:last.setdefault(sid,row)
        nodes=[]
        for sid in ids:
            rows=by_sid[sid];recent=last.get(sid);clear=cleared.get(sid)
            pilots=sorted({p['name'] for row in rows for p in row['pilots']});state='contact' if rows else 'clear' if clear and now-clear<=min(600,p['ttl_minutes']*60) else 'old' if history and recent else 'quiet'
            contacts=rows or ([recent] if state=='old' and recent['state']=='contact' else [])
            nodes.append({**universe.systems[sid],'distance':distance.get(sid),'in_range':distance.get(sid) is not None and distance[sid]<=p['jumps'],'state':state,'pilots':pilots,'contacts':[{'id':r['id'],'timestamp':r['timestamp'],'pilots':r['pilots'],'ships':r.get('ships',[]),'scan_links':r.get('scan_links',[]),'count':r.get('count'),'ambiguous':r['ambiguous'],'historical':r.get('historical',False)} for r in contacts],'reported_at':max(r['timestamp'] for r in rows) if rows else clear if state=='clear' else recent['timestamp'] if recent and state=='old' else None,'characters':[c['name'] for c in pos if c['system_id']==sid],'reports':[r['id'] for r in rows]})
            nodes[-1]['kill_groups']=kill_by_system[sid]
        for report in reports:report['system_names']=[universe.systems[sid]['name'] for sid in report['systems']]
        manual_names={cid:universe.systems[sid]['name'] for cid,sid in p['manual_locations'].items() if sid in universe.systems}
        with self.lock:status=dict(self.status)
        alert_data=collect_alerts(self.store,universe,now);alerts=alert_data['items']
        kill_regions=intel_kills.regions(p,pos,universe)
        return {'preferences':p,'notifications_enabled':alert_data['notifications_enabled'],'manual_system_names':manual_names,'status':status,'characters':pos,'reference':reference,'region_id':region,'region_name':regions.get(region),'center':center,'nodes':nodes,'edges':[[a,b] for a,b in universe.edges if a in ids and b in ids],'reports':reports[:500],'alerts':alerts,'kill_groups':kill_groups,'kill_regions':sorted(kill_regions),'kill_feed':intel_kills.source(self.store),'clipped':clipped,'universe_build':universe.build,'regions':sorted(regions.items(),key=lambda r:r[1]),'calculated_at':now}
