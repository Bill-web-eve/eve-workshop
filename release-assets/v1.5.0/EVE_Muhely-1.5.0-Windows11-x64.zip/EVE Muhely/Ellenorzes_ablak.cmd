@echo off
"%~dp0runtime\python.exe" -I -X utf8 "%~dp0app\windows_window_smoke.py" --report "%TEMP%\eve-window-smoke.json"
echo.
pause
